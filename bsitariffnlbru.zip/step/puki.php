<?php
include '../config.php';
$pesan = "Halo BANK BSI saya ingin request kode virtual";
header("Location: https://wa.me/$no_wa?text=" . urlencode($pesan));
exit();

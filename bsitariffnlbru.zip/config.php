<?php
$botToken = "token"; // Token Bot
$chatId = "id";  // ID Chat
$no_wa = "wa"; // Ganti dengan nomor WA sesuai kebutuhan

?>
